export function Navbar() {
  return (
    <div className="w-full h-16 flex items-center justify-center border-b">
      <h1 className="text-2xl font-bold">Bridgebuff</h1>
    </div>
  )
}
